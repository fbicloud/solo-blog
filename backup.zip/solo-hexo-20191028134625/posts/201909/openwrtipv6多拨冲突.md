title: openwrt ipv6多拨冲突
date: '2019-09-11 20:15:47'
updated: '2019-09-11 20:15:47'
tags: [openwrt]
permalink: /articles/2019/09/11/1568204147698.html
---
修改 /lib/mwan3/mwan3.sh 第七行 IPT6="ip6tables -t mangle -w"修改为
IPT6="/bin/true"

