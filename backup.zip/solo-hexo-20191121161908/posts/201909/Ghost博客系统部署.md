title: Ghost博客系统部署
date: '2019-09-08 19:33:25'
updated: '2019-09-08 19:53:48'
tags: [待分类]
permalink: /articles/2019/09/08/1567942405522.html
---
1. 安装nginx 
	略
1. 安装mysql
	略
1. 安装nvm
	[nvm教程传送门](https://www.runoob.com/w3cnote/nvm-manager-node-versions.html)
1. Ghost-cli安装
	`sudo adduser <user>`	#用户名不可为ghost
	`usermod -aG sudo <user>`	#赋予用户sudo权限
	`su - <user>`	#登录已创建的用户
	`sudo npm install ghost-cli@latest -g` #安装ghost-cli
	`mkdir xxx`	#创建安装目录
	`cd xxx`	#进入安装目录
	`ghost install`	#安装Ghost

	[Ghost官方教程](https://ghost.org/docs/setup/)
