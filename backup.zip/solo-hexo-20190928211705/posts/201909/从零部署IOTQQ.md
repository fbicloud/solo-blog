title: 从零部署IOTQQ
date: '2019-09-26 21:47:00'
updated: '2019-09-26 22:25:41'
tags: [待分类]
permalink: /articles/2019/09/26/1569505620644.html
---
[项目地址](https://github.com/IOTQQ/IOTQQ)
首先你要了解Github 公网 端口是什么，如果不知道的话可以x掉网页了。在右上角❤️ 
1. 下载
![QQ截图20190926213600.png](https://img.hacpai.com/file/2019/09/QQ截图20190926213600-f2cc130a.png)
![QQ截图20190926213624.png](https://img.hacpai.com/file/2019/09/QQ截图20190926213624-4646657d.png)
1. 解压后打开配置文件
![QQ截图20190926213820.png](https://img.hacpai.com/file/2019/09/QQ截图20190926213820-22f90ae0.png)
1. 编辑配置文件
![QQ截图20190926214632.png](https://img.hacpai.com/file/2019/09/QQ截图20190926214632-dff7fab6.png)
![QQ截图20190926214358.png](https://img.hacpai.com/file/2019/09/QQ截图20190926214358-bc86e7ac.png)
1. 双击鼠标左键运行
![QQ截图20190926215322.png](https://img.hacpai.com/file/2019/09/QQ截图20190926215322-67efbad8.png)
1. 打开浏览器访问`http://127.0.0.1:8888/v1/Github/InstallService`，控制台输出如下即为成功 
*注：将127.0.0.1:8888替换为你的公网地址*
![QQ截图20190926220424.png](https://img.hacpai.com/file/2019/09/QQ截图20190926220424-6d46b7ce.png)
1. 打开`http://127.0.0.1:8888/v1/Login/GetQRcode`扫码登陆即可
![QQ截图20190926222453.png](https://img.hacpai.com/file/2019/09/QQ截图20190926222453-4a03f8a1.png)

