title: linux终端设置代理
date: '2019-09-08 19:12:21'
updated: '2019-09-08 19:12:21'
tags: [待分类]
permalink: /articles/2019/09/08/1567941141500.html
---
```
export http_proxy=127.0.0.1:1080
export https_proxy=127.0.0.1:1080
```
