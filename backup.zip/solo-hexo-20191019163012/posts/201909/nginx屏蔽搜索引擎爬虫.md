title: nginx屏蔽搜索引擎爬虫
date: '2019-09-08 19:14:20'
updated: '2019-09-08 19:14:33'
tags: [待分类]
permalink: /articles/2019/09/08/1567941260024.html
---
````
  if ($http_user_agent ~* "qihoobot|Baiduspider|Googlebot|Googlebot-Mobile|Googlebot-Image|Mediapartners-Google|Adsbot-Google|Feedfetcher-Google|Yahoo! Slurp|Yahoo! Slurp China|YoudaoBot|Sosospider|Sogou spider|Sogou web spider|MSNBot|ia_archiver|Tomato Bot") 
  {  
  return 403;  
  }  
````
