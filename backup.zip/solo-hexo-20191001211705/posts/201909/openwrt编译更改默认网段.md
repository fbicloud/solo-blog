title: openwrt编译更改默认网段
date: '2019-09-10 22:10:39'
updated: '2019-09-11 03:42:44'
tags: [openwrt]
permalink: /articles/2019/09/10/1568124639776.html
---
`./package/base-files/files/bin/config_generate`

