title: Ubuntu18.04同步时区
date: '2019-11-08 13:14:45'
updated: '2019-11-08 13:15:22'
tags: [ubuntu]
permalink: /articles/2019/11/08/1573190085542.html
---
查看所有时区
`timedatectl list-timezones`
设置时区为中国上海
`sudo timedatectl set-timezone Asia/Shanghai`
