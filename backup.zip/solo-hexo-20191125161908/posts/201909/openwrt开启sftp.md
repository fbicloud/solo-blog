title: openwrt开启sftp
date: '2019-09-11 03:39:43'
updated: '2019-09-11 03:43:56'
tags: [openwrt]
permalink: /articles/2019/09/11/1568144383900.html
---
```
opkg update
opkg install openssh-sftp-server
```
