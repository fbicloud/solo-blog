title: 干掉systemd-resolved
date: '2019-09-12 23:54:19'
updated: '2019-09-12 23:54:19'
tags: [待分类]
permalink: /articles/2019/09/12/1568303659457.html
---
编辑/etc/NetworkManager/NetworkManager.conf ，在main中加入`dns=default`
```
sudo systemctl disable systemd-resolved.service
sudo service systemd-resolved stop
rm /etc/resolv.conf
sudo service network-manager restart
```
